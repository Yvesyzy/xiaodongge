---
name: codex-task-cleanup
description: Safe, repeatable cleanup workflow for Codex task artifacts and repository clutter. Use when the user asks to clean redundant files, remove generated artifacts, tidy caches, archive stale docs or sprint outputs, reduce dependency clutter, or run an end-of-task cleanup check without affecting project behavior.
---

# Codex Task Cleanup

Use this skill to inspect and clean repository clutter without damaging user work.
Default to a scan-and-plan workflow. Delete only when the target is low risk,
inside the intended project or task folder, and backed by evidence.

## Operating Modes

### End-of-task check

Use before final handoff when cleanup is part of the task or the user asked for
Codex task hygiene.

Allowed actions:
- Remove disposable files created during the current task inside the current
  task folder, especially `tmp/` scratch files, empty temp directories, transient
  logs, and failed intermediate outputs.
- Leave deliverables, reports, screenshots, source files, scan reports, and user
  supplied files unless the user explicitly asked to remove them.
- Report any non-trivial cleanup opportunities instead of acting on them.

### Repo cleanup

Use when the user explicitly asks to clean a repository, remove clutter, archive
stale artifacts, or reduce dependency/docs/test bloat.

Required behavior:
- Build a cleanup plan first.
- Separate low-risk generated artifacts from tracked project assets.
- Ask for confirmation before deleting, moving, or rewriting anything that may
  affect source behavior, documentation history, data, dependencies, tests, or
  project configuration.
- Verify after cleanup with the cheapest meaningful checks available; treat a timeout, cancellation, missing output, stale output, or nonzero exit as failed verification, and never report cleanup as successful until the expected postcondition is observed.

## Non-Negotiable Safety Rules

- Never clean outside the current git root, current task folder, or explicit
  user-provided path.
- Never delete or move files from `D:\codex\.codex-home`, installed skills,
  plugins, caches, memory, session data, or configuration unless the user names
  that exact path and asks for that exact cleanup.
- Never treat source code, tests, migrations, lock files, package manifests,
  `.env*`, secrets, databases, datasets, media assets, or user-provided files as
  disposable.
- Never use recursive deletion against a computed path until the resolved
  absolute path has been printed and verified to stay inside the intended root.
- Never enumerate paths in PowerShell and pass them to `cmd /c`, batch builtins,
  or another shell for deletion or movement.
- Never use destructive `git clean` modes. Use `git clean -nd`, `git clean -ndX`,
  or equivalent dry runs only.
- Prefer archive or leave-in-place over deletion when usage is uncertain.
- If the user wants deletion that is not clearly low risk, present the exact
  file list, risk class, rollback path, and validation plan before acting.

## Workflow

### 1. Establish scope

Identify the intended cleanup root:
- Prefer the current git root from `git rev-parse --show-toplevel`.
- If no git root exists, use the current task folder or explicit user path.
- If multiple roots are plausible, ask the user before touching files.

Record:
- Working directory.
- Git root or non-git root.
- Current branch if available.
- User-stated cleanup goal.

### 2. Capture baseline

Run non-destructive inspection first:

```powershell
git status --short --branch
git status --porcelain --untracked-files=all
git clean -nd
git clean -ndX
```

If the repo has known checks, record the lightest useful baseline command before
cleanup. Examples: `npm test`, `pnpm test`, `python -m pytest`, `cargo test`,
`go test ./...`, `docker compose config`, or a local project checker.

Do not invent a test command. Read package files, project docs, CI files, or
existing scripts to identify exact commands.

### 3. Inventory clutter

Classify files into these groups:

| Class | Examples | Default action |
| --- | --- | --- |
| Low-risk generated | `__pycache__/`, `.pytest_cache/`, `.coverage`, `htmlcov/`, `dist/`, `build/`, temp logs, known tool scratch output | Remove only after path verification, or list for confirmation |
| Task scratch | Current task `tmp/`, failed drafts, transient downloads, temporary source mirrors | Remove if created during this task and not a deliverable |
| Archive-worthy | completed plans, old reports, sprint artifacts, POC notes, historical docs | Move to an archive folder after confirmation |
| Consolidate | scattered test outputs, benchmark reports, agent scratch folders | Move after preserving unique content and updating references |
| Protected | source, tests, configs, lock files, data, assets, user files, secrets | Do not clean automatically |

Use exact commands suited to the OS and repo. On Windows, prefer PowerShell
native commands with `-LiteralPath`.

### 4. Validate usage before removal

Before removing or archiving anything beyond low-risk generated files:
- Check whether the file is tracked: `git ls-files -- <path>`.
- Search references with `rg` using exact filenames and import names.
- For docs, check incoming links and README/index references.
- For dependency cleanup, inspect manifests and imports, remove one package at a
  time only after explicit user approval, then run tests.
- For duplicates, compare exact content hashes and keep the better-located copy.

If usage cannot be proven, keep the file or archive it.

### 5. Produce a cleanup plan

Before non-trivial action, show a compact plan:

```markdown
## Cleanup Plan

Root: <absolute path>
Mode: end-of-task | repo cleanup

| Action | Path | Why safe | Risk | Rollback |
| --- | --- | --- | --- | --- |
| delete | <path> | ignored generated cache | low | regenerates |
| archive | <path> | completed report, linked nowhere | medium | restore from archive |

Validation:
- <command or reason no command exists>
```

### 6. Execute conservatively

For low-risk deletion:
- Resolve every target path.
- Verify each path is inside the intended root.
- Delete with PowerShell `Remove-Item -LiteralPath`.
- Avoid globs in destructive commands.

For archive:
- Use `.archive/cleanup/YYYYMMDD-HHMMSS/` or the repo's existing archive
  location.
- Preserve relative paths when useful.
- For tracked files, prefer `git mv` after confirmation.
- Update docs and references in the same cleanup if paths changed.

For dependency cleanup:
- Do not update or remove many dependencies at once.
- Keep package manifest and lock file changes together.
- Run the package manager's install/check command after each change.

### 7. Verify and report

After cleanup:
- Re-run `git status --short`.
- Re-run the selected validation command if available.
- Confirm expected files were removed or archived.
- Report what changed, what was intentionally left, and remaining risks.

Use this output shape:

```markdown
Cleaned:
- <path> - <reason>

Archived:
- <path> -> <archive path> - <reason>

Left untouched:
- <path> - <risk or missing evidence>

Validation:
- <command>: <result>

Remaining risks:
- <short note or "none identified">
```

## Cleanup Decisions

Delete only when all are true:
- The file is generated, ignored, temporary, or created during this task.
- It is not tracked source or user-provided content.
- It can be regenerated or has no value after the task.
- The resolved path is inside scope.

Archive when any are true:
- The file may be useful later but is not active.
- It is historical docs, sprint output, POC material, or old reports.
- Deletion would be hard to justify but current root clutter is real.

Ask before acting when any are true:
- The file is tracked.
- The file affects builds, tests, dependencies, configs, docs navigation, data,
  or runtime behavior.
- The file is large and its origin is unclear.
- The cleanup changes project structure.
- The rollback path is not obvious.

## Common Patterns

Generated artifacts:
- Python: `__pycache__/`, `*.pyc`, `.pytest_cache/`, `.coverage`, `htmlcov/`,
  `*.egg-info/`, `build/`, `dist/`.
- Node: `node_modules/` only when explicitly requested, `.next/`, `coverage/`,
  `dist/`, `build/`, package manager caches.
- General: `*.tmp`, `*.bak`, `*.log`, tool scratch folders, failed generated
  exports.

Docs and sprint artifacts:
- Keep active docs at root or `docs/`.
- Archive completed plans, reports, POCs, and old progress notes.
- Preserve links or update references after movement.

Scattered outputs:
- Move test outputs to a gitignored `tests/outputs/` only after confirmation.
- Move benchmark generated results to a gitignored benchmark output folder.
- Keep fixtures and source benchmark scripts.

Dependency clutter:
- Analyze before changing.
- Remove or update one dependency at a time.
- Run tests/build/type checks after each change.
- Document any package left in place because usage was uncertain.
